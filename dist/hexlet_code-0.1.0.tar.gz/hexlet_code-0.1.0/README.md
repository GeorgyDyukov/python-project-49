### Hexlet tests and linter status:
[![Actions Status](https://github.com/GeorgyDyukov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/GeorgyDyukov/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8b532050edad3fd4e4f5/maintainability)](https://codeclimate.com/github/GeorgyDyukov/python-project-49/maintainability)
